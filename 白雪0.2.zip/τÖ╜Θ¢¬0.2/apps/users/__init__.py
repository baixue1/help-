import pymysql
pymysql.install_as_MySQLdb()

default_app_config = 'users.apps.UsersConfig'